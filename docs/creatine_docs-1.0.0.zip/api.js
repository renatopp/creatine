YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "BoxSizer",
        "DeviceManager",
        "DiscreteBar",
        "DisplayManager",
        "Emitter",
        "FactoryManager",
        "FadeIn",
        "FadeInOut",
        "FadeOut",
        "FlexBitmap",
        "Game",
        "Gamepad",
        "GamepadManager",
        "GridSizer",
        "ImageLayer",
        "IsometricTileLayer",
        "KeyboardManager",
        "Map",
        "MouseManager",
        "MoveIn",
        "MoveOut",
        "ObjectLayer",
        "OrthogonalTileLayer",
        "Plugin",
        "PluginManager",
        "ProgressBar",
        "ResourceManager",
        "Scene",
        "SceneManager",
        "Scroll",
        "SoundManager",
        "StaggeredTileLayer",
        "StorageManager",
        "System",
        "TileLayer",
        "Tileset",
        "TimeManager",
        "Touch",
        "TouchManager",
        "ZoomIn",
        "ZoomInOut",
        "ZoomOut",
        "angleDirection",
        "angleDistance",
        "buttons",
        "clip",
        "core",
        "getJSON",
        "keys",
        "merge",
        "newId",
        "pad",
        "randomInt",
        "randomPolar",
        "shuffle",
        "wrapAngle"
    ],
    "modules": [
        "constants",
        "core functions",
        "creatine",
        "creatine.tmx",
        "creatine.transitions",
        "legacy"
    ],
    "allModules": [
        {
            "displayName": "constants",
            "name": "constants",
            "description": "The list of all constants in creatine."
        },
        {
            "displayName": "core functions",
            "name": "core functions",
            "description": "The list of all functions inside creatine.\n\n\n## Usage examples\n\n    tine.wrapAngle(-20); // = 340\n    \n    tine.randInt(0, 20); // = 3\n    \n    tine.merge({b:6}, {a:5}); // {a:5, b:6}"
        },
        {
            "displayName": "creatine",
            "name": "creatine",
            "description": "Creatine is a power-up to the CreateJS libraries, providing data structures \nand algorithms for game development. You see here:\n\n- **Scene management** - *with scene stacks based on Cocos2D Director*\n- **Scene transitions** - *you can also create new transitions*\n- **Input handling** - *keyboard, mouse, touch and gamepads*\n- **Resources and Factories** - *facilitates the access to PreloadJS*\n- **Sound handling** - *facilitates the access to SoundJS*\n- **Storage helper** - *easy use of localStorage*\n- **Plugins** - *create and install plugins that work together with the \nengine*\n- **Particles** - *a fast particle system for canvas*\n- **Tile Maps** - *total integration with Tiled, supporting all map \nprojections*\n\nFeel free to use, modify, improve, make additions and suggestions.\n\n## Usage\n\nYou can access creatine function by the namespace `creatine` or its shortcut\n`tine`:\n\n    console.log(creatine.VERSION);\n    \n    // is the same as\n    console.log(tine.VERSION);\n\nTo start your development with creatine, you need to create a Game object, \nwhich will create a canvas object inside the page. The basic signature for \nthe game object:\n\n    var game = new tine.Game(config, state);\n    \nwhere `config` is a configuration object or an url for a JSON, and `state` \nis a collection of functions that will be called by the game in certain \nmoments.\n\nYou can use 5 functions inside the state: `boot`, `preload`, `create`, \n`update`, or `draw`. The `boot` function is called right after the game \ncreate the canvas and initialize the managers and right before the \npreloading; you can initialize 3th party libraries here. The `preload` \nfunction is called after booting and before the preloading itself; you can \nadd items to be loaded here. When preloading is finished, the game call the\n`create` function, where you can create the objects of you game or \ninitialize the base scenes. The functions `update` and `draw` are called \nperiodically in that order. The recommended way to pass these function is \nlike this:\n\n    var game = new tine.Game(null, {\n      boot    : function() { ... },\n      preload : function() { ... },\n      create  : function() { ... },\n      update  : function() { ... },\n      draw    : function() { ... }\n    })\n\nThe configuration object must be an object or an url for a JSON in the \nfollowing format:\n\n    var config = {\n      project          : 'creatine_game',\n      width            : 800,\n      height           : 600,\n      container        : null,\n      framerate        : 60,\n      showfps          : false,\n      background_color : '#000',\n      resources        : {\n        base_path : './',\n        manifest  : []\n      }\n    }\n\nThis configuration is also the default options of the engine. You can \nprovide only a part of these variables because game will use the default \nconfiguration for missing values.\n\n## Links\n\n- **Site**: http://creatine.guineashots.com\n- **Repository**: http://github.com/renatopp/creatine\n- **API**: http://docs.guineashots.com/creatine\n- **User Guide**: http://docs.guineashots.com/creatine/guide\n- **Examples**: http://creatine.guineashots.com/examples"
        },
        {
            "displayName": "creatine.tmx",
            "name": "creatine.tmx"
        },
        {
            "displayName": "creatine.transitions",
            "name": "creatine.transitions"
        },
        {
            "displayName": "legacy",
            "name": "legacy",
            "description": "NOTE: The legacy functions will be removed or changed in the next versions."
        }
    ]
} };
});